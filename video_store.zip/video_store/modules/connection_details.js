var user= 'sqluser';
var password = 'password';
var host = 'localhost';
var database = 'video_store';

module.exports = {user:user, password: password, host: host, database:database};
